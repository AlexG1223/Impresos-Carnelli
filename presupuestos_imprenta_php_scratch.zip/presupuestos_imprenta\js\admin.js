// js/admin.js — PresuPrint Pro

let maquinasList = [];
let insumosList  = [];
let troquelesList = [];
let editMaquinaId = null;
let editInsumoId  = null;
let editTroquelId = null;

function toggleViasField() {
    const iTipo = document.getElementById('i_tipo');
    const grupoVias = document.getElementById('grupo_vias');
    if (!iTipo || !grupoVias) return;
    if (iTipo.value === 'papel') {
        grupoVias.style.display = 'block';
    } else {
        grupoVias.style.display = 'none';
        document.getElementById('i_vias').value = '1';
    }
}

// ── KPIs Dashboard ────────────────────────────────────────────────────────────
async function cargarKPIs() {
    try {
        const res    = await fetch('api/presupuestos.php?stats=1');
        const result = await res.json();
        if (result.success && result.data) {
            const d = result.data;
            const fmt = v => parseFloat(v || 0).toLocaleString('es-CL', { maximumFractionDigits: 0 });
            document.getElementById('kpi-total').innerText    = d.total_mes || '0';
            document.getElementById('kpi-ventas').innerText   = '$' + fmt(d.ventas_aprobadas_mes);
            document.getElementById('kpi-promedio').innerText = '$' + fmt(d.promedio_precio);
            document.getElementById('kpi-clientes').innerText = d.clientes_unicos || '0';
        }
    } catch (e) { console.error('Error cargando KPIs', e); }
}

// ── DOMContentLoaded ──────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    cargarKPIs();
    cargarMaquinas();
    cargarInsumos();
    cargarTroqueles();

    const iTipoSelect = document.getElementById('i_tipo');
    if (iTipoSelect) {
        iTipoSelect.addEventListener('change', toggleViasField);
    }
    toggleViasField();

    // Formulario máquinas
    document.getElementById('form-maquina').addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            id:                editMaquinaId,
            nombre:            document.getElementById('m_nombre').value,
            formato_max_ancho: document.getElementById('m_fmax_ancho').value,
            formato_max_largo: document.getElementById('m_fmax_largo').value,
            formato_min_ancho: document.getElementById('m_fmin_ancho').value,
            formato_min_largo: document.getElementById('m_fmin_largo').value,
            medida_pinza:      document.getElementById('m_pinza').value,
            costo_hora:        document.getElementById('m_costo').value,
            costo_puesta:      document.getElementById('m_costo_puesta').value,
            velocidad_por_hora: document.getElementById('m_velocidad').value
        };
        const res    = await fetch('api/maquinas.php', { method: 'POST', body: JSON.stringify(data) });
        const result = await res.json();
        if (result.success) {
            e.target.reset();
            editMaquinaId = null;
            document.querySelector('#form-maquina button[type="submit"]').innerText = 'Guardar Máquina';
            cargarMaquinas();
            cargarKPIs();
        } else {
            alert(result.message);
        }
    });

    // Formulario insumos
    document.getElementById('form-insumo').addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            id:                 editInsumoId,
            tipo:               document.getElementById('i_tipo').value,
            nombre:             document.getElementById('i_nombre').value,
            gramaje:            document.getElementById('i_gramaje').value,
            formato_ancho:      document.getElementById('i_ancho').value,
            formato_largo:      document.getElementById('i_largo').value,
            costo_unidad:       document.getElementById('i_costo').value,
            unidades_por_paquete: document.getElementById('i_unidades').value,
            vias:               document.getElementById('i_vias').value
        };
        const res    = await fetch('api/insumos.php', { method: 'POST', body: JSON.stringify(data) });
        const result = await res.json();
        if (result.success) {
            e.target.reset();
            editInsumoId = null;
            document.querySelector('#form-insumo button[type="submit"]').innerText = 'Guardar Insumo';
            toggleViasField();
            cargarInsumos();
        } else {
            alert(result.message);
        }
    });

    // Formulario troqueles
    document.getElementById('form-troquel').addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            id:    editTroquelId,
            nombre: document.getElementById('t_nombre').value,
            ancho:  document.getElementById('t_ancho').value,
            largo:  document.getElementById('t_largo').value,
            bocas:  document.getElementById('t_bocas').value
        };
        const res    = await fetch('api/troqueles.php', { method: 'POST', body: JSON.stringify(data) });
        const result = await res.json();
        if (result.success) {
            e.target.reset();
            editTroquelId = null;
            document.querySelector('#form-troquel button[type="submit"]').innerText = 'Guardar Troquel';
            cargarTroqueles();
        } else {
            alert(result.message);
        }
    });
});

// ── Carga tablas ──────────────────────────────────────────────────────────────
async function cargarMaquinas() {
    const res    = await fetch('api/maquinas.php');
    const result = await res.json();
    const tbody  = document.querySelector('#tabla-maquinas tbody');
    tbody.innerHTML = '';

    if (result.success && result.data) {
        maquinasList = result.data;
        result.data.forEach(m => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${m.nombre}</td>
                <td>${m.formato_max_ancho} x ${m.formato_max_largo} cm</td>
                <td>${m.formato_min_ancho} x ${m.formato_min_largo} cm</td>
                <td>$${m.costo_hora}</td>
                <td>$${m.costo_puesta ?? 0}</td>
                <td>${m.velocidad_por_hora ?? 5000}</td>
                <td><div class="btn-icon-row">
                    <button onclick="editarMaquina(${m.id})" class="btn btn-primary btn-sm">Editar</button>
                    <button onclick="eliminarMaquina(${m.id})" class="btn btn-danger btn-sm">Eliminar</button>
                </div></td>
            `;
            tbody.appendChild(tr);
        });
    }
}

async function cargarInsumos() {
    const res    = await fetch('api/insumos.php');
    const result = await res.json();
    const tbody  = document.querySelector('#tabla-insumos tbody');
    tbody.innerHTML = '';

    if (result.success && result.data) {
        insumosList = result.data;
        result.data.forEach(i => {
            let extraInfo = '-';
            if (i.tipo === 'papel') {
                let viasText = '';
                if (i.vias && i.vias > 1) {
                    viasText = ` - ${i.vias} vías`;
                }
                extraInfo = `${i.formato_ancho}x${i.formato_largo}cm ${i.gramaje}g${viasText}`;
            }
            const costoUnit = (i.costo_unidad / i.unidades_por_paquete).toFixed(2);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="text-transform: capitalize;">${i.tipo}</td>
                <td>${i.nombre}</td>
                <td>${extraInfo}</td>
                <td>$${costoUnit}</td>
                <td><div class="btn-icon-row">
                    <button onclick="editarInsumo(${i.id})" class="btn btn-primary btn-sm">Editar</button>
                    <button onclick="eliminarInsumo(${i.id})" class="btn btn-danger btn-sm">Eliminar</button>
                </div></td>
            `;
            tbody.appendChild(tr);
        });
    }
}

async function cargarTroqueles() {
    const res    = await fetch('api/troqueles.php');
    const result = await res.json();
    const tbody  = document.querySelector('#tabla-troqueles tbody');
    tbody.innerHTML = '';

    if (result.success && result.data) {
        troquelesList = result.data;
        result.data.forEach(t => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${t.nombre}</td>
                <td>${t.ancho} cm</td>
                <td>${t.largo} cm</td>
                <td>${t.bocas}</td>
                <td><div class="btn-icon-row">
                    <button onclick="editarTroquel(${t.id})" class="btn btn-primary btn-sm">Editar</button>
                    <button onclick="eliminarTroquel(${t.id})" class="btn btn-danger btn-sm">Eliminar</button>
                </div></td>
            `;
            tbody.appendChild(tr);
        });
    }
}

// ── Editar ────────────────────────────────────────────────────────────────────
function editarMaquina(id) {
    const m = maquinasList.find(x => parseInt(x.id) === parseInt(id));
    if (!m) return;
    editMaquinaId = m.id;
    document.getElementById('m_nombre').value      = m.nombre;
    document.getElementById('m_fmax_ancho').value  = m.formato_max_ancho;
    document.getElementById('m_fmax_largo').value  = m.formato_max_largo;
    document.getElementById('m_fmin_ancho').value  = m.formato_min_ancho;
    document.getElementById('m_fmin_largo').value  = m.formato_min_largo;
    document.getElementById('m_pinza').value       = m.medida_pinza;
    document.getElementById('m_costo').value       = m.costo_hora;
    document.getElementById('m_costo_puesta').value = m.costo_puesta ?? 0;
    document.getElementById('m_velocidad').value   = m.velocidad_por_hora ?? 5000;
    document.querySelector('#form-maquina button[type="submit"]').innerText = 'Actualizar Máquina';
    document.getElementById('m_nombre').focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function editarInsumo(id) {
    const i = insumosList.find(x => parseInt(x.id) === parseInt(id));
    if (!i) return;
    editInsumoId = i.id;
    document.getElementById('i_tipo').value     = i.tipo;
    document.getElementById('i_nombre').value   = i.nombre;
    document.getElementById('i_gramaje').value  = i.gramaje ?? '';
    document.getElementById('i_ancho').value    = i.formato_ancho ?? '';
    document.getElementById('i_largo').value    = i.formato_largo ?? '';
    document.getElementById('i_costo').value    = i.costo_unidad;
    document.getElementById('i_unidades').value = i.unidades_por_paquete;
    document.getElementById('i_vias').value     = i.vias ?? 1;
    toggleViasField();
    document.querySelector('#form-insumo button[type="submit"]').innerText = 'Actualizar Insumo';
    document.getElementById('i_nombre').focus();
    const top = document.getElementById('form-insumo').getBoundingClientRect().top + window.scrollY;
    window.scrollTo({ top: top - 100, behavior: 'smooth' });
}

function editarTroquel(id) {
    const t = troquelesList.find(x => parseInt(x.id) === parseInt(id));
    if (!t) return;
    editTroquelId = t.id;
    document.getElementById('t_nombre').value = t.nombre;
    document.getElementById('t_ancho').value  = t.ancho;
    document.getElementById('t_largo').value  = t.largo;
    document.getElementById('t_bocas').value  = t.bocas;
    document.querySelector('#form-troquel button[type="submit"]').innerText = 'Actualizar Troquel';
    document.getElementById('t_nombre').focus();
    const top = document.getElementById('form-troquel').getBoundingClientRect().top + window.scrollY;
    window.scrollTo({ top: top - 100, behavior: 'smooth' });
}

// ── Eliminar ──────────────────────────────────────────────────────────────────
async function eliminarMaquina(id) {
    if (!confirm('¿Seguro que deseas eliminar esta máquina?')) return;
    const res    = await fetch('api/maquinas.php?id=' + id, { method: 'DELETE' });
    const result = await res.json();
    if (result.success) cargarMaquinas();
}

async function eliminarInsumo(id) {
    if (!confirm('¿Seguro que deseas eliminar este insumo?')) return;
    const res    = await fetch('api/insumos.php?id=' + id, { method: 'DELETE' });
    const result = await res.json();
    if (result.success) cargarInsumos();
}

async function eliminarTroquel(id) {
    if (!confirm('¿Seguro que deseas eliminar este troquel?')) return;
    const res    = await fetch('api/troqueles.php', { method: 'DELETE', body: JSON.stringify({ id }) });
    const result = await res.json();
    if (result.success) cargarTroqueles();
}
