<?php
// api/config.php

// Configuración de la base de datos MySQL (XAMPP por defecto)
$host = "localhost";
$username = "root";
$password = "";
$database = "imprenta_presupuestos";

// Intentar establecer la conexión
try {
    $dsn = "mysql:host=$host;dbname=$database;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, $username, $password, $options);

    // --- AUTO-PATCH: columnas y tablas nuevas ---

    // Patch 1: costo_puesta en maquinas
    try { $pdo->exec("ALTER TABLE maquinas ADD COLUMN costo_puesta DECIMAL(10, 2) NOT NULL DEFAULT 0"); }
    catch (PDOException $e) { /* Ya existe */ }

    // Patch 2: velocidad_por_hora en maquinas
    try { $pdo->exec("ALTER TABLE maquinas ADD COLUMN velocidad_por_hora INT NOT NULL DEFAULT 5000"); }
    catch (PDOException $e) { /* Ya existe */ }

    // Patch 3: tabla troqueles
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS troqueles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nombre VARCHAR(255) NOT NULL,
            ancho DECIMAL(10,2) NOT NULL,
            largo DECIMAL(10,2) NOT NULL,
            bocas INT NOT NULL,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
    } catch (PDOException $e) { /* Ya existe */ }

    // Patch 4: tabla clientes
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS clientes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nombre VARCHAR(150) NOT NULL,
            empresa VARCHAR(150),
            telefono VARCHAR(50),
            email VARCHAR(150),
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
    } catch (PDOException $e) { /* Ya existe */ }

    // Patch 5: tabla presupuestos_guardados
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS presupuestos_guardados (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT,
            descripcion VARCHAR(255) NOT NULL,
            tipo_trabajo ENUM('corte_recto','troquel') DEFAULT 'corte_recto',
            ancho_final DECIMAL(10,2),
            largo_final DECIMAL(10,2),
            cantidad_pedida INT NOT NULL,
            demasia_porcentaje FLOAT DEFAULT 0,
            papel_id INT,
            colores INT DEFAULT 1,
            frente_dorso ENUM('si','no') DEFAULT 'no',
            usa_troquel TINYINT(1) DEFAULT 0,
            troquel_id INT DEFAULT NULL,
            ruta_maquinas VARCHAR(500),
            ruta_maquinas_nombres TEXT,
            poses_por_pliego INT,
            pliegos_necesarios INT,
            horas_estimadas DECIMAL(10,2),
            costo_papel DECIMAL(12,2),
            costo_impresion DECIMAL(12,2),
            costo_total DECIMAL(12,2),
            porcentaje_ganancia FLOAT DEFAULT 0,
            ganancia_valor DECIMAL(12,2),
            porcentaje_comision FLOAT DEFAULT 0,
            comision_valor DECIMAL(12,2),
            porcentaje_iva FLOAT DEFAULT 19,
            iva_valor DECIMAL(12,2),
            precio_final DECIMAL(12,2),
            estado ENUM('borrador','enviado','aprobado','rechazado') DEFAULT 'borrador',
            observaciones TEXT,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cliente (cliente_id),
            INDEX idx_estado (estado),
            INDEX idx_fecha (creado_en)
        )");
    } catch (PDOException $e) { /* ya existe */ }

    // Patch 6: vias en insumos e insertar datos autocopiantes de prueba
    try {
        $pdo->exec("ALTER TABLE insumos ADD COLUMN vias TINYINT NOT NULL DEFAULT 1 COMMENT 'Cantidad de vias para papel autocopiante'");
    } catch (PDOException $e) { /* Ya existe */ }

    try {
        $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM insumos WHERE nombre = ?");
        
        $stmtCheck->execute(['Autocopiante Duplicado 56g']);
        if ($stmtCheck->fetchColumn() == 0) {
            $pdo->exec("INSERT INTO insumos (tipo, nombre, gramaje, formato_ancho, formato_largo, costo_unidad, unidades_por_paquete, vias) VALUES
            ('papel', 'Autocopiante Duplicado 56g', 56, 72.0, 102.0, 60000.00, 500, 2)");
        }
        
        $stmtCheck->execute(['Autocopiante Triplicado 56g']);
        if ($stmtCheck->fetchColumn() == 0) {
            $pdo->exec("INSERT INTO insumos (tipo, nombre, gramaje, formato_ancho, formato_largo, costo_unidad, unidades_por_paquete, vias) VALUES
            ('papel', 'Autocopiante Triplicado 56g', 56, 72.0, 102.0, 90000.00, 500, 3)");
        }
    } catch (PDOException $e) { /* Silenciar si falla */ }

} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode([
        "success" => false,
        "message" => "Error de conexión a la base de datos: " . $e->getMessage()
    ]);
    exit;
}

// Función utilitaria para respuestas JSON estandarizadas
function sendJsonResponse($success, $data = null, $message = null)
{
    header('Content-Type: application/json; charset=utf-8');
    $response = ['success' => $success];
    if ($data !== null) $response['data'] = $data;
    if ($message !== null) $response['message'] = $message;
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// Cabeceras CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
?>