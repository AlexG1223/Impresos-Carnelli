<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'POST') {
    sendJsonResponse(false, null, "Método no soportado");
}

$data = json_decode(file_get_contents("php://input"), true);
if (!$data)
    sendJsonResponse(false, null, "Datos inválidos");

$cantidad_pedida = intval($data['cantidad'] ?? 0);

function calcularPresupuesto($pdo, $data, $cantidad_pedida) {
    $demasia_porcentaje = floatval($data['demasia'] ?? 0);
    $papel_id = intval($data['papel_id'] ?? 0);
    $colores = max(1, intval($data['colores'] ?? 1));
    $frente_dorso = $data['frente_dorso'] ?? 'no';
    $ruta_maquinas_ids = $data['ruta_maquinas'] ?? [];
    
    $cantidad_produccion = ceil($cantidad_pedida * (1 + ($demasia_porcentaje / 100)));
    $warnings = [];
    
    $usa_troquel = isset($data['usa_troquel']) ? $data['usa_troquel'] : false;
    
    if ($usa_troquel) {
        $ancho_final = floatval($data['troquel_ancho'] ?? 0);
        $largo_final = floatval($data['troquel_largo'] ?? 0);
        $troquel_bocas = intval($data['troquel_bocas'] ?? 1);
        if ($troquel_bocas <= 0) $troquel_bocas = 1;
        $cantidad_elementos = ceil($cantidad_produccion / $troquel_bocas);
    } else {
        $ancho_final = floatval($data['ancho'] ?? 0);
        $largo_final = floatval($data['largo'] ?? 0);
        $cantidad_elementos = $cantidad_produccion;
    }
    
    if ($ancho_final <= 0 || $largo_final <= 0 || $cantidad_pedida <= 0 || $papel_id <= 0) {
        throw new Exception("Datos insuficientes (medidas, cantidad o papel faltante).");
    }
    
    if (empty($ruta_maquinas_ids) || !is_array($ruta_maquinas_ids)) {
        throw new Exception("Debe especificar una ruta de producción con al menos una máquina.");
    }
    
    // 0. Obtener papel
    $stmtPapel = $pdo->prepare("SELECT * FROM insumos WHERE id = ? AND tipo = 'papel'");
    $stmtPapel->execute([$papel_id]);
    $papel = $stmtPapel->fetch();
    
    if (!$papel) {
        throw new Exception("Papel no encontrado en la base de datos.");
    }
    
    $p_ancho = floatval($papel['formato_ancho']);
    $p_largo = floatval($papel['formato_largo']);
    $unidades_pqte = max(1, intval($papel['unidades_por_paquete']));
    $costo_hoja_compra = floatval($papel['costo_unidad']) / $unidades_pqte;
    $vias = max(1, isset($papel['vias']) ? intval($papel['vias']) : 1);
    
    // 1. Obtener datos de todas las máquinas en la ruta
    $ids_string = implode(',', array_map('intval', $ruta_maquinas_ids));
    $stmtMaquinas = $pdo->query("SELECT * FROM maquinas WHERE id IN ($ids_string)");
    $maquinas_db = [];
    while ($row = $stmtMaquinas->fetch()) {
        $maquinas_db[$row['id']] = $row;
    }
    
    $ruta_nodos = [];
    foreach ($ruta_maquinas_ids as $id) {
        if (!isset($maquinas_db[$id])) {
            throw new Exception("La máquina con ID $id ya no existe o es inválida.");
        }
        $ruta_nodos[] = $maquinas_db[$id];
    }
    
    $maquina_principal = $ruta_nodos[0];
    
    $m_ancho = floatval($maquina_principal['formato_max_ancho']);
    $m_largo = floatval($maquina_principal['formato_max_largo']);
    $m_pinza = floatval($maquina_principal['medida_pinza']);
    
    // Cuántos pliegos de máquina salen de una hoja de compra (del proveedor)
    $cortes_1 = floor($p_ancho / $m_ancho) * floor($p_largo / $m_largo);
    $cortes_2 = floor($p_ancho / $m_largo) * floor($p_largo / $m_ancho);
    $cortes_por_hoja = max($cortes_1, $cortes_2);
    
    if ($cortes_por_hoja <= 0) {
        $cortes_por_hoja = 1;
        $util_ancho = $p_ancho;
        $util_largo = $p_largo - $m_pinza;
    } else {
        $util_ancho = $m_ancho;
        $util_largo = $m_largo - $m_pinza;
    }
    
    // Validar si el trabajo "final" cabe al menos una vez en el pliego útil principal
    if (!(($ancho_final <= $util_ancho && $largo_final <= $util_largo) || ($largo_final <= $util_ancho && $ancho_final <= $util_largo))) {
        throw new Exception("El trabajo (" . $ancho_final . "x" . $largo_final . ") no cabe físicamente en el área útil de impresión de la primera máquina (" . $maquina_principal['nombre'] . ").");
    }
    
    // Advertencia si el trabajo es más pequeño que el MÍNIMO de la máquina
    $min_ancho = floatval($maquina_principal['formato_min_ancho']);
    $min_largo = floatval($maquina_principal['formato_min_largo']);
    if ($min_ancho > 0 && $min_largo > 0) {
        if ($ancho_final < $min_ancho || $largo_final < $min_largo) {
            $warnings[] = "AVISO: El trabajo ({$ancho_final}x{$largo_final} cm) es más pequeño que el mínimo de '{$maquina_principal['nombre']}' ({$min_ancho}x{$min_largo} cm). Considerar otra máquina o usar troquel multi-boca.";
        }
    }
    
    // Calculo de poses
    $poses_opcion1 = floor($util_ancho / $ancho_final) * floor($util_largo / $largo_final);
    $poses_opcion2 = floor($util_ancho / $largo_final) * floor($util_largo / $ancho_final);
    $poses = max($poses_opcion1, $poses_opcion2);
    
    if ($poses <= 0) {
        throw new Exception("Error matemático al computar las poses en la máquina principal.");
    }
    
    // Pliegos y papel base necesarios
    $pliegos_necesarios_offset = ceil($cantidad_elementos / $poses);
    $hojas_necesarias = ceil($pliegos_necesarios_offset / $cortes_por_hoja);
    $costo_papel = $hojas_necesarias * $costo_hoja_compra * $vias;
    
    if ($vias > 1) {
        $warnings[] = "Papel autocopiante detectado ({$vias} vías): el costo de papel se multiplicó por {$vias}.";
    }
    
    // Iteramos por todo el flujo de trabajo
    $costo_produccion_total = 0;
    $horas_totales = 0;
    $nombres_secuencia = [];
    
    foreach ($ruta_nodos as $idx => $maq) {
        $velocidad = (isset($maq['velocidad_por_hora']) && floatval($maq['velocidad_por_hora']) > 0) ? floatval($maq['velocidad_por_hora']) : 5000;
        $costo_hr = floatval($maq['costo_hora']);
        $costo_fijo = isset($maq['costo_puesta']) ? floatval($maq['costo_puesta']) : 0;
        
        if ($idx === 0) {
            $cantidad_procesar = $pliegos_necesarios_offset;
            $tiempo_hr = $cantidad_procesar / $velocidad;
            if ($frente_dorso === 'si') {
                $tiempo_hr *= 2;
                $costo_fijo = $costo_fijo * ($colores * 2);
            } else {
                $costo_fijo = $costo_fijo * $colores;
            }
        } else {
            $cantidad_procesar = $cantidad_elementos;
            $tiempo_hr = $cantidad_procesar / $velocidad;
        }
        
        $costo_paso = ($tiempo_hr * $costo_hr) + $costo_fijo;
        
        $horas_totales += $tiempo_hr;
        $costo_produccion_total += $costo_paso;
        $nombres_secuencia[] = $maq['nombre'];
    }
    
    $costo_total = ceil($costo_produccion_total + $costo_papel);
    
    // Lógica Comercial
    $p_ganancia = floatval($data['ganancia'] ?? 0);
    $p_comision = floatval($data['comision'] ?? 0);
    $p_iva = floatval($data['iva'] ?? 0);
    
    $ganancia_valor = ceil($costo_total * ($p_ganancia / 100));
    $comision_valor = ceil($costo_total * ($p_comision / 100));
    
    $subtotal_venta = $costo_total + $ganancia_valor + $comision_valor;
    
    $iva_valor = ceil($subtotal_venta * ($p_iva / 100));
    $precio_final = $subtotal_venta + $iva_valor;
    
    return [
        'maquina_nombre' => implode(' ➔ ', $nombres_secuencia),
        'poses_por_pliego' => $poses,
        'pliegos_necesarios' => $pliegos_necesarios_offset,
        'horas_estimadas' => round($horas_totales, 2),
        'costo_papel' => ceil($costo_papel),
        'costo_impresion' => ceil($costo_produccion_total),
        'costo_estimado' => $costo_total,
        'ganancia_valor' => $ganancia_valor,
        'comision_valor' => $comision_valor,
        'subtotal_venta' => $subtotal_venta,
        'iva_valor' => $iva_valor,
        'precio_final' => $precio_final,
        'warnings' => $warnings
    ];
}

try {
    if (isset($data['cantidades']) && is_array($data['cantidades'])) {
        $respuestas = [];
        foreach ($data['cantidades'] as $qty) {
            try {
                $calc = calcularPresupuesto($pdo, $data, intval($qty));
                $respuestas[$qty] = [
                    'success' => true,
                    'data' => $calc
                ];
            } catch (Exception $e) {
                $respuestas[$qty] = [
                    'success' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        
        // Calcular el principal también
        $principal = calcularPresupuesto($pdo, $data, $cantidad_pedida);
        
        sendJsonResponse(true, [
            'principal' => $principal,
            'alternativas' => $respuestas
        ], "Cálculos por lote completados");
    } else {
        $principal = calcularPresupuesto($pdo, $data, $cantidad_pedida);
        sendJsonResponse(true, $principal, "Cálculo realizado exitosamente");
    }
} catch (Exception $e) {
    sendJsonResponse(false, null, $e->getMessage());
}
?>