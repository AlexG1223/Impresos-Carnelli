<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT * FROM insumos ORDER BY tipo ASC, nombre ASC");
        sendJsonResponse(true, $stmt->fetchAll());
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data)
            sendJsonResponse(false, null, "Datos inválidos");

        $gramaje = isset($data['gramaje']) && $data['gramaje'] !== '' ? $data['gramaje'] : null;
        $formato_ancho = isset($data['formato_ancho']) && $data['formato_ancho'] !== '' ? $data['formato_ancho'] : null;
        $formato_largo = isset($data['formato_largo']) && $data['formato_largo'] !== '' ? $data['formato_largo'] : null;
        $unidades = isset($data['unidades_por_paquete']) && $data['unidades_por_paquete'] !== '' ? $data['unidades_por_paquete'] : 1;
        $vias = isset($data['vias']) && $data['vias'] !== '' ? intval($data['vias']) : 1;

        if (isset($data['id']) && $data['id']) {
            $sql = "UPDATE insumos SET tipo=?, nombre=?, gramaje=?, formato_ancho=?, formato_largo=?, costo_unidad=?, unidades_por_paquete=?, vias=? WHERE id=?";
            $stmt = $pdo->prepare($sql);
            try {
                $stmt->execute([
                    $data['tipo'],
                    $data['nombre'],
                    $gramaje,
                    $formato_ancho,
                    $formato_largo,
                    $data['costo_unidad'],
                    $unidades,
                    $vias,
                    $data['id']
                ]);
                sendJsonResponse(true, ['id' => $data['id']], "Insumo actualizado exitosamente");
            } catch (PDOException $e) {
                sendJsonResponse(false, null, "Error al actualizar: " . $e->getMessage());
            }
        } else {
            $sql = "INSERT INTO insumos (tipo, nombre, gramaje, formato_ancho, formato_largo, costo_unidad, unidades_por_paquete, vias) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            try {
                $stmt->execute([
                    $data['tipo'],
                    $data['nombre'],
                    $gramaje,
                    $formato_ancho,
                    $formato_largo,
                    $data['costo_unidad'],
                    $unidades,
                    $vias
                ]);
                sendJsonResponse(true, ['id' => $pdo->lastInsertId()], "Insumo agregado exitosamente");
            } catch (PDOException $e) {
                sendJsonResponse(false, null, "Error al guardar: " . $e->getMessage());
            }
        }
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? null;
        if (!$id)
            sendJsonResponse(false, null, "ID no proporcionado");

        $stmt = $pdo->prepare("DELETE FROM insumos WHERE id = ?");
        $stmt->execute([$id]);
        sendJsonResponse(true, null, "Insumo eliminado exitosamente");
        break;

    default:
        sendJsonResponse(false, null, "Método no soportado");
        break;
}
?>