// js/calculador.js — PresuPrint Pro v3

let rutaTrabajo = [];
let todasLasMaquinas = [];
let troquelesDisponibles = [];
let ultimoCalculo = null; // Guarda el último resultado calculado
let alternativasCalculadas = []; // Almacena todas las alternativas calculadas y sus resultados

document.addEventListener('DOMContentLoaded', () => {
    cargarPapeles();
    cargarMaquinasList();
    cargarTroquelesList();
    cargarClientesSelect();

    // ── Añadir máquina a la ruta ──────────────────────────────────────────
    document.getElementById('btn-add-ruta').addEventListener('click', () => {
        const sel = document.getElementById('ruta_selector');
        const id = sel.value;
        if (!id) return;
        const nombre = sel.options[sel.selectedIndex].text;
        rutaTrabajo.push({ id, nombre });
        renderRuta();
    });

    // ── Cambio de troquel ─────────────────────────────────────────────────
    document.getElementById('c_troquel_select').addEventListener('change', (e) => {
        const val = e.target.value;
        const estandar = document.getElementById('grupo_dimensiones_estandar');
        const troquel  = document.getElementById('grupo_dimensiones_troquel');

        if (!val) {
            estandar.style.display = 'flex';
            troquel.classList.remove('visible');
            document.getElementById('c_ancho').required = true;
            document.getElementById('c_largo').required = true;
            document.getElementById('c_troquel_ancho').value = '';
            document.getElementById('c_troquel_largo').value = '';
            document.getElementById('c_troquel_bocas').value = '';
        } else {
            estandar.style.display = 'none';
            troquel.classList.add('visible');
            document.getElementById('c_ancho').required = false;
            document.getElementById('c_largo').required = false;

            const t = troquelesDisponibles.find(x => x.id == val);
            if (t) {
                document.getElementById('c_troquel_ancho').value = t.ancho;
                document.getElementById('c_troquel_largo').value = t.largo;
                document.getElementById('c_troquel_bocas').value = t.bocas;
            }
        }
    });

    // ── Submit calculador ─────────────────────────────────────────────────
    document.getElementById('form-calculador').addEventListener('submit', async (e) => {
        e.preventDefault();

        if (rutaTrabajo.length === 0) {
            mostrarError('Debe agregar al menos una máquina a la ruta de producción.');
            return;
        }

        const submitBtn = e.target.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Calculando...';

        const qList = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 20000, 30000];

        const data = {
            usa_troquel:   document.getElementById('c_troquel_select').value !== '',
            ancho:         document.getElementById('c_ancho').value,
            largo:         document.getElementById('c_largo').value,
            troquel_ancho: document.getElementById('c_troquel_ancho').value,
            troquel_largo: document.getElementById('c_troquel_largo').value,
            troquel_bocas: document.getElementById('c_troquel_bocas').value,
            cantidad:      document.getElementById('c_cantidad').value,
            demasia:       document.getElementById('c_demasia').value,
            ganancia:      document.getElementById('c_ganancia').value,
            comision:      document.getElementById('c_comision').value,
            iva:           document.getElementById('c_iva').value,
            papel_id:      document.getElementById('c_papel').value,
            colores:       document.getElementById('c_colores').value,
            frente_dorso:  document.getElementById('c_frente_dorso').value,
            ruta_maquinas: rutaTrabajo.map(m => m.id),
            cantidades:    qList
        };

        try {
            const res = await fetch('api/calcular.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await res.json();

            const resultBox   = document.getElementById('result-box');
            const errorBox    = document.getElementById('error-box');
            const warningsBox = document.getElementById('warnings-box');
            const savePanel   = document.getElementById('save-panel');
            const alternativasBox = document.getElementById('alternativas-box');
            const alternativasGrid = document.getElementById('alternativas-grid');

            if (result.success) {
                errorBox.style.display = 'none';
                
                // Extraer el resultado principal y las alternativas de la respuesta por lote
                const req = result.data.principal;
                const alternativas = result.data.alternativas;

                // ── Mostrar warnings de mínimos ───────────────────────────
                if (req.warnings && req.warnings.length > 0) {
                    warningsBox.innerHTML = req.warnings.map(w =>
                        `<div class="alert alert-warning">⚠️ ${w}</div>`
                    ).join('');
                    warningsBox.style.display = 'block';
                } else {
                    warningsBox.style.display = 'none';
                }

                // ── Poblar resultado ──────────────────────────────────────
                resultBox.classList.add('visible');
                document.getElementById('r_maquina').innerText   = req.maquina_nombre;
                document.getElementById('r_poses').innerText     = req.poses_por_pliego;
                document.getElementById('r_pliegos').innerText   = req.pliegos_necesarios;
                document.getElementById('r_tiempo').innerText    = req.horas_estimadas + ' hr';
                document.getElementById('r_costo_papel').innerText = 'Papel: $' + req.costo_papel.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_costo_imp').innerText   = 'Producción: $' + req.costo_impresion.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_costo_base').innerText  = '$' + req.costo_estimado.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_ganancia_valor').innerText = '$' + req.ganancia_valor.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_comision_valor').innerText = '$' + req.comision_valor.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_subtotal_venta').innerText = '$' + req.subtotal_venta.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_iva_valor').innerText      = '$' + req.iva_valor.toLocaleString('es-CL', { maximumFractionDigits: 0 });
                document.getElementById('r_precio_final').innerText   = '$' + req.precio_final.toLocaleString('es-CL', { maximumFractionDigits: 0 });

                // Guardar resultado para usarlo al guardar presupuesto
                ultimoCalculo = { data, result: req };

                // ── Mostrar panel de guardar ──────────────────────────────
                savePanel.classList.add('visible');
                const desc = document.getElementById('c_desc').value;
                if (desc) document.getElementById('s_descripcion').value = desc;

                // ── Renderizar Alternativas de Cantidad ───────────────────
                alternativasCalculadas = [];
                alternativasGrid.innerHTML = '';
                
                let idx = 0;
                for (const qty of qList) {
                    const altRes = alternativas[qty];
                    if (altRes && altRes.success) {
                        const altData = { ...data, cantidad: qty };
                        alternativasCalculadas.push({
                            qty: qty,
                            data: altData,
                            result: altRes
                        });
                        
                        const card = document.createElement('div');
                        card.className = 'alt-card';
                        card.dataset.index = idx;
                        
                        const unitPrice = altRes.data.precio_final / qty;
                        
                        // Auto-seleccionar si coincide con la cantidad principal
                        const isMainQty = parseInt(qty) === parseInt(data.cantidad);
                        if (isMainQty) {
                            card.classList.add('selected');
                        }
                        
                        card.innerHTML = `
                            <div class="alt-chk"><i data-feather="check" style="width:10px;height:10px;"></i></div>
                            <div class="alt-qty">${qty.toLocaleString('es-CL')} U.</div>
                            <div class="alt-price">$ ${altRes.data.precio_final.toLocaleString('es-CL', { maximumFractionDigits: 0 })}</div>
                            <div class="alt-unit">$ ${unitPrice.toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} c/u</div>
                        `;
                        
                        card.addEventListener('click', () => {
                            card.classList.toggle('selected');
                            actualizarSeleccionAlternativas();
                        });
                        
                        alternativasGrid.appendChild(card);
                        idx++;
                    }
                }
                
                if (typeof feather !== 'undefined') feather.replace();
                
                alternativasBox.style.display = 'block';
                actualizarSeleccionAlternativas();

                // Scroll suave al resultado
                resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });

            } else {
                resultBox.classList.remove('visible');
                savePanel.classList.remove('visible');
                alternativasBox.style.display = 'none';
                warningsBox.style.display = 'none';
                mostrarError(result.message);
            }
        } catch (err) {
            mostrarError('Error de red o servidor: ' + err.message);
        }

        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i data-feather="cpu"></i> Calcular Ruta';
        if (typeof feather !== 'undefined') feather.replace();
    });

    // ── Guardar presupuesto ───────────────────────────────────────────────
    document.getElementById('btn-guardar-presupuesto').addEventListener('click', async () => {
        if (!ultimoCalculo) return;

        const desc = document.getElementById('s_descripcion').value.trim();
        if (!desc) {
            mostrarFeedbackGuardar('error', 'La descripción del trabajo es requerida.');
            return;
        }

        const clienteSelect = document.getElementById('s_cliente_select');
        const clienteId     = clienteSelect.value;
        let clienteNuevo    = null;

        if (clienteId === '__nuevo__') {
            const nombre = document.getElementById('s_cli_nombre').value.trim();
            if (!nombre) {
                mostrarFeedbackGuardar('error', 'El nombre del cliente nuevo es requerido.');
                return;
            }
            clienteNuevo = {
                nombre,
                empresa:  document.getElementById('s_cli_empresa').value.trim(),
                telefono: document.getElementById('s_cli_telefono').value.trim(),
                email:    document.getElementById('s_cli_email').value.trim()
            };
        }

        const { data: inputData, result: res } = ultimoCalculo;
        const troquelId = document.getElementById('c_troquel_select').value || null;

        const payload = {
            cliente_id:   (clienteId && clienteId !== '__nuevo__') ? clienteId : null,
            cliente_nuevo: clienteNuevo,
            descripcion:   desc,
            tipo_trabajo:  troquelId ? 'troquel' : 'corte_recto',
            ancho_final:   inputData.usa_troquel ? (inputData.troquel_ancho || null) : (inputData.ancho || null),
            largo_final:   inputData.usa_troquel ? (inputData.troquel_largo || null) : (inputData.largo || null),
            cantidad_pedida:    inputData.cantidad,
            demasia_porcentaje: inputData.demasia,
            papel_id:     inputData.papel_id || null,
            colores:      inputData.colores,
            frente_dorso: inputData.frente_dorso,
            usa_troquel:  inputData.usa_troquel,
            troquel_id:   troquelId,
            ruta_maquinas:        rutaTrabajo.map(m => m.id).join(','),
            ruta_maquinas_nombres: res.maquina_nombre,
            poses_por_pliego:   res.poses_por_pliego,
            pliegos_necesarios: res.pliegos_necesarios,
            horas_estimadas:    res.horas_estimadas,
            costo_papel:        res.costo_papel,
            costo_impresion:    res.costo_impresion,
            costo_total:        res.costo_estimado,
            porcentaje_ganancia: inputData.ganancia,
            ganancia_valor:     res.ganancia_valor,
            porcentaje_comision: inputData.comision,
            comision_valor:     res.comision_valor,
            porcentaje_iva:     inputData.iva,
            iva_valor:          res.iva_valor,
            precio_final:       res.precio_final,
            estado:       'borrador',
            observaciones: document.getElementById('s_observaciones').value.trim()
        };

        const btn = document.getElementById('btn-guardar-presupuesto');
        btn.disabled = true;
        btn.textContent = 'Guardando...';

        try {
            const r = await fetch('api/presupuestos.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const rJson = await r.json();

            if (rJson.success) {
                mostrarFeedbackGuardar('success',
                    `✅ Presupuesto #${rJson.data.id} guardado correctamente. <a href="historial.html" style="color:var(--primary-color); font-weight:600;">Ver en Historial →</a>`
                );
                // Refrescar lista de clientes por si se creó uno nuevo
                cargarClientesSelect();
            } else {
                mostrarFeedbackGuardar('error', '❌ Error: ' + rJson.message);
            }
        } catch (err) {
            mostrarFeedbackGuardar('error', 'Error de red: ' + err.message);
        }

        btn.disabled = false;
        btn.textContent = '💾 Guardar Presupuesto';
    });

    // ── Toggle campos nuevo cliente ───────────────────────────────────────
    document.getElementById('s_cliente_select').addEventListener('change', (e) => {
        const nuevoFields = document.getElementById('cliente-nuevo-fields');
        if (e.target.value === '__nuevo__') {
            nuevoFields.classList.add('visible');
        } else {
            nuevoFields.classList.remove('visible');
        }
    });

    // ── Gestión de Selección de Alternativas ──────────────────────────────
    function actualizarSeleccionAlternativas() {
        const selectedCards = document.querySelectorAll('.alt-card.selected');
        const count = selectedCards.length;
        
        const txt = document.getElementById('alt-selected-text');
        if (count === 1) {
            txt.innerText = '1 opción seleccionada';
        } else {
            txt.innerText = `${count} opciones seleccionadas`;
        }
        
        const actionsPanel = document.getElementById('alternativas-actions');
        if (count > 0) {
            actionsPanel.classList.add('visible');
        } else {
            actionsPanel.classList.remove('visible');
        }
    }

    // ── Enviar al Cliente (Compartir) ────────────────────────────────────
    document.getElementById('btn-bulk-share').addEventListener('click', () => {
        const selectedCards = document.querySelectorAll('.alt-card.selected');
        if (selectedCards.length === 0) {
            alert('Por favor seleccione al menos una alternativa para enviar.');
            return;
        }
        
        const desc = document.getElementById('s_descripcion').value.trim() || document.getElementById('c_desc').value.trim() || 'Trabajo de Imprenta';
        const obs = document.getElementById('s_observaciones').value.trim();
        
        let msg = `*PRESUPUESTO: ${desc}*\n\n`;
        msg += `Estimado cliente, a continuación detallamos las alternativas de presupuesto para su trabajo:\n\n`;
        
        selectedCards.forEach(card => {
            const idx = card.dataset.index;
            const alt = alternativasCalculadas[idx];
            const unitPrice = alt.result.data.precio_final / alt.qty;
            msg += `• *${alt.qty.toLocaleString('es-CL')} unidades*:\n`;
            msg += `  Total: $ ${alt.result.data.precio_final.toLocaleString('es-CL', { maximumFractionDigits: 0 })} c/IVA\n`;
            msg += `  Precio Unitario: $ ${unitPrice.toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} c/u\n\n`;
        });
        
        if (obs) {
            msg += `*Observaciones:*\n${obs}\n\n`;
        }
        
        msg += `Quedamos a su entera disposición ante cualquier consulta o para dar inicio al trabajo.`;
        
        // Cargar texto en textarea
        document.getElementById('share-text-content').value = msg;
        
        // Link WhatsApp
        const encodedMsg = encodeURIComponent(msg);
        document.getElementById('btn-whatsapp-share').href = `https://api.whatsapp.com/send?text=${encodedMsg}`;
        
        // Mostrar modal
        document.getElementById('modal-compartir').classList.remove('hidden');
    });

    const cerrarModalCompartir = () => {
        document.getElementById('modal-compartir').classList.add('hidden');
    };
    
    document.getElementById('btn-close-share').addEventListener('click', cerrarModalCompartir);
    document.getElementById('btn-close-share-footer').addEventListener('click', cerrarModalCompartir);
    
    // Copiar al portapapeles
    document.getElementById('btn-copy-share').addEventListener('click', () => {
        const textarea = document.getElementById('share-text-content');
        textarea.select();
        textarea.setSelectionRange(0, 99999);
        
        try {
            navigator.clipboard.writeText(textarea.value).then(() => {
                const copyBtn = document.getElementById('btn-copy-share');
                const origHtml = copyBtn.innerHTML;
                copyBtn.innerHTML = '✓ ¡Copiado!';
                copyBtn.disabled = true;
                setTimeout(() => {
                    copyBtn.innerHTML = origHtml;
                    copyBtn.disabled = false;
                }, 2000);
            });
        } catch (err) {
            document.execCommand('copy');
            alert('Texto copiado al portapapeles.');
        }
    });

    // ── Guardar seleccionados en Historial ───────────────────────────────
    document.getElementById('btn-bulk-save').addEventListener('click', async () => {
        const selectedCards = document.querySelectorAll('.alt-card.selected');
        if (selectedCards.length === 0) {
            alert('Por favor seleccione al menos una alternativa para guardar.');
            return;
        }
        
        const desc = document.getElementById('s_descripcion').value.trim();
        if (!desc) {
            mostrarFeedbackGuardar('error', 'La descripción del trabajo es requerida.');
            document.getElementById('save-panel').scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }
        
        const clienteSelect = document.getElementById('s_cliente_select');
        const clienteId     = clienteSelect.value;
        let clienteNuevo    = null;
        
        if (clienteId === '__nuevo__') {
            const nombre = document.getElementById('s_cli_nombre').value.trim();
            if (!nombre) {
                mostrarFeedbackGuardar('error', 'El nombre del cliente nuevo es requerido.');
                document.getElementById('save-panel').scrollIntoView({ behavior: 'smooth', block: 'center' });
                return;
            }
            clienteNuevo = {
                nombre,
                empresa:  document.getElementById('s_cli_empresa').value.trim(),
                telefono: document.getElementById('s_cli_telefono').value.trim(),
                email:    document.getElementById('s_cli_email').value.trim()
            };
        }
        
        const btn = document.getElementById('btn-bulk-save');
        const origText = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<i class="spinner"></i> Guardando...';
        
        let finalClienteId = (clienteId && clienteId !== '__nuevo__') ? clienteId : null;
        
        try {
            // Si el cliente es nuevo, lo creamos primero
            if (clienteId === '__nuevo__' && clienteNuevo) {
                const cr = await fetch('api/clientes.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(clienteNuevo)
                });
                const crJson = await cr.json();
                if (crJson.success && crJson.data && crJson.data.id) {
                    finalClienteId = crJson.data.id;
                    clienteNuevo = null; 
                    await cargarClientesSelect();
                    document.getElementById('s_cliente_select').value = finalClienteId;
                    const nuevoFields = document.getElementById('cliente-nuevo-fields');
                    nuevoFields.classList.remove('visible');
                } else {
                    throw new Error(crJson.message || 'Error al crear el cliente.');
                }
            }
            
            const troquelId = document.getElementById('c_troquel_select').value || null;
            const observaciones = document.getElementById('s_observaciones').value.trim();
            
            let guardadosCount = 0;
            let fallidosCount = 0;
            
            for (let i = 0; i < selectedCards.length; i++) {
                const idx = selectedCards[i].dataset.index;
                const alt = alternativasCalculadas[idx];
                const inputData = alt.data;
                const res = alt.result.data;
                
                const payload = {
                    cliente_id:   finalClienteId,
                    cliente_nuevo: null,
                    descripcion:   `${desc} (x${alt.qty})`,
                    tipo_trabajo:  troquelId ? 'troquel' : 'corte_recto',
                    ancho_final:   inputData.usa_troquel ? (inputData.troquel_ancho || null) : (inputData.ancho || null),
                    largo_final:   inputData.usa_troquel ? (inputData.troquel_largo || null) : (inputData.largo || null),
                    cantidad_pedida:    alt.qty,
                    demasia_porcentaje: inputData.demasia,
                    papel_id:     inputData.papel_id || null,
                    colores:      inputData.colores,
                    frente_dorso: inputData.frente_dorso,
                    usa_troquel:  inputData.usa_troquel,
                    troquel_id:   troquelId,
                    ruta_maquinas:        rutaTrabajo.map(m => m.id).join(','),
                    ruta_maquinas_nombres: res.maquina_nombre,
                    poses_por_pliego:   res.poses_por_pliego,
                    pliegos_necesarios: res.pliegos_necesarios,
                    horas_estimadas:    res.horas_estimadas,
                    costo_papel:        res.costo_papel,
                    costo_impresion:    res.costo_impresion,
                    costo_total:        res.costo_estimado,
                    porcentaje_ganancia: inputData.ganancia,
                    ganancia_valor:     res.ganancia_valor,
                    porcentaje_comision: inputData.comision,
                    comision_valor:     res.comision_valor,
                    porcentaje_iva:     inputData.iva,
                    iva_valor:          res.iva_valor,
                    precio_final:       res.precio_final,
                    estado:       'borrador',
                    observaciones: observaciones
                };
                
                btn.innerHTML = `Guardando (${i + 1}/${selectedCards.length})...`;
                
                try {
                    const r = await fetch('api/presupuestos.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });
                    const rJson = await r.json();
                    if (rJson.success) {
                        guardadosCount++;
                    } else {
                        console.error('Error guardando alternativa:', rJson.message);
                        fallidosCount++;
                    }
                } catch (e) {
                    console.error('Error de red al guardar alternativa:', e);
                    fallidosCount++;
                }
            }
            
            if (fallidosCount === 0) {
                mostrarFeedbackGuardar('success',
                    `✅ ${guardadosCount} presupuestos guardados correctamente en el historial. <a href="historial.html" style="color:var(--primary-color); font-weight:600;">Ver en Historial →</a>`
                );
            } else {
                mostrarFeedbackGuardar('success',
                    `⚠️ Se guardaron ${guardadosCount} presupuestos. Fallaron ${fallidosCount}. <a href="historial.html" style="color:var(--primary-color); font-weight:600;">Ver en Historial →</a>`
                );
            }
            
            await cargarClientesSelect();
            if (finalClienteId) {
                document.getElementById('s_cliente_select').value = finalClienteId;
            }
            
        } catch (err) {
            mostrarFeedbackGuardar('error', 'Error en el proceso de guardado: ' + err.message);
        }
        
        btn.disabled = false;
        btn.innerHTML = origText;
    });
});

// ── Helpers UI ────────────────────────────────────────────────────────────────
function mostrarError(msg) {
    const errorBox = document.getElementById('error-box');
    errorBox.style.display = 'block';
    errorBox.innerHTML = '⚠ ' + msg;
    errorBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function mostrarFeedbackGuardar(tipo, msg) {
    const fb = document.getElementById('save-feedback');
    fb.style.display = 'block';
    fb.className = `alert alert-${tipo === 'success' ? 'success' : 'error'} full-width`;
    fb.innerHTML = msg;
}

// ── Carga datos remotos ───────────────────────────────────────────────────────
async function cargarPapeles() {
    try {
        const res    = await fetch('api/insumos.php');
        const result = await res.json();
        const select = document.getElementById('c_papel');

        if (result.success && result.data) {
            select.innerHTML = '<option value="">Seleccione Papel...</option>';
            result.data.filter(i => i.tipo === 'papel').forEach(p => {
                const opt = document.createElement('option');
                opt.value    = p.id;
                let viasLabel = '';
                if (p.vias && p.vias > 1) {
                    if (p.vias == 2) viasLabel = ' — DUPLICADO (2 vías)';
                    else if (p.vias == 3) viasLabel = ' — TRIPLICADO (3 vías)';
                    else viasLabel = ` — ${p.vias} vías`;
                }
                opt.innerText = `${p.nombre} - ${p.gramaje}g (${p.formato_ancho}x${p.formato_largo}cm)${viasLabel}`;
                select.appendChild(opt);
            });
        }
    } catch (e) {
        console.error('Error cargando papeles', e);
    }
}

async function cargarMaquinasList() {
    try {
        const res    = await fetch('api/maquinas.php');
        const result = await res.json();
        todasLasMaquinas = result.data || [];
        const select = document.getElementById('ruta_selector');

        if (result.success && result.data) {
            select.innerHTML = '<option value="">Seleccione una máquina para añadir...</option>';
            result.data.forEach(m => {
                const opt = document.createElement('option');
                opt.value    = m.id;
                opt.innerText = m.nombre;
                select.appendChild(opt);
            });
        }
    } catch (e) {
        console.error('Error cargando maquinas', e);
    }
}

async function cargarTroquelesList() {
    try {
        const res    = await fetch('api/troqueles.php');
        const result = await res.json();
        const select = document.getElementById('c_troquel_select');

        if (result.success && result.data) {
            troquelesDisponibles = result.data;
            select.innerHTML = '<option value="">No usar troquel (Corte Recto)</option>';
            result.data.forEach(t => {
                const opt = document.createElement('option');
                opt.value    = t.id;
                opt.innerText = `${t.nombre} (${t.ancho}x${t.largo}cm - ${t.bocas} bocas)`;
                select.appendChild(opt);
            });
        }
    } catch (e) {
        console.error('Error cargando troqueles', e);
    }
}

async function cargarClientesSelect() {
    try {
        const res    = await fetch('api/clientes.php');
        const result = await res.json();
        const select = document.getElementById('s_cliente_select');

        if (result.success && result.data) {
            select.innerHTML = '<option value="">Sin cliente asignado</option>';
            result.data.forEach(c => {
                const opt = document.createElement('option');
                opt.value    = c.id;
                opt.innerText = c.nombre + (c.empresa ? ` (${c.empresa})` : '');
                select.appendChild(opt);
            });
            // Agregar opción nuevo cliente al final
            const nuevo = document.createElement('option');
            nuevo.value    = '__nuevo__';
            nuevo.innerText = '+ Nuevo Cliente';
            select.appendChild(nuevo);
        }
    } catch (e) {
        console.error('Error cargando clientes', e);
    }
}

// ── Ruta de producción ────────────────────────────────────────────────────────
function renderRuta() {
    const ul = document.getElementById('lista_ruta');
    ul.innerHTML = '';
    rutaTrabajo.forEach((m, index) => {
        const li = document.createElement('li');
        li.className = 'ruta-item';
        li.innerHTML = `<span><b style="color:var(--primary-color)">Paso ${index + 1}:</b> ${m.nombre}</span>
            <button type="button" class="btn btn-danger btn-sm" onclick="eliminarPaso(${index})">Quitar</button>`;
        ul.appendChild(li);
    });
}

function eliminarPaso(index) {
    rutaTrabajo.splice(index, 1);
    renderRuta();
}
