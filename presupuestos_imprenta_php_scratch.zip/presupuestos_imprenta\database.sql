-- ═══════════════════════════════════════════════════════
-- PresuPrint Pro — Schema completo MySQL
-- ═══════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS imprenta_presupuestos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE imprenta_presupuestos;

-- ─── Máquinas de impresión ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS maquinas (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    nombre              VARCHAR(100) NOT NULL,
    formato_max_ancho   FLOAT NOT NULL,
    formato_max_largo   FLOAT NOT NULL,
    formato_min_ancho   FLOAT NOT NULL DEFAULT 0,
    formato_min_largo   FLOAT NOT NULL DEFAULT 0,
    medida_pinza        FLOAT NOT NULL,
    costo_hora          DECIMAL(10, 2) NOT NULL,
    costo_puesta        DECIMAL(10, 2) NOT NULL DEFAULT 0,
    velocidad_por_hora  INT NOT NULL DEFAULT 5000,
    creado_en           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Insumos (Papel, Tintas, Chapas, Otros) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS insumos (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    tipo                ENUM('papel', 'tinta', 'chapa', 'otro') NOT NULL,
    nombre              VARCHAR(100) NOT NULL,
    gramaje             INT DEFAULT NULL,
    formato_ancho       FLOAT DEFAULT NULL,
    formato_largo       FLOAT DEFAULT NULL,
    costo_unidad        DECIMAL(10, 2) NOT NULL,
    unidades_por_paquete INT DEFAULT 1,
    vias                TINYINT NOT NULL DEFAULT 1 COMMENT 'Cantidad de vias para papel autocopiante',
    creado_en           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Formatos estándar ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS formatos_impresion (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(50) NOT NULL,
    ancho       FLOAT NOT NULL,
    largo       FLOAT NOT NULL,
    creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Troqueles ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS troqueles (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(255) NOT NULL,
    ancho       DECIMAL(10,2) NOT NULL,
    largo       DECIMAL(10,2) NOT NULL,
    bocas       INT NOT NULL,
    creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Clientes ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clientes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(150) NOT NULL,
    empresa     VARCHAR(150),
    telefono    VARCHAR(50),
    email       VARCHAR(150),
    creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Presupuestos Guardados ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS presupuestos_guardados (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id            INT,
    descripcion           VARCHAR(255) NOT NULL,
    tipo_trabajo          ENUM('corte_recto','troquel') DEFAULT 'corte_recto',
    ancho_final           DECIMAL(10,2),
    largo_final           DECIMAL(10,2),
    cantidad_pedida       INT NOT NULL,
    demasia_porcentaje    FLOAT DEFAULT 0,
    papel_id              INT,
    colores               INT DEFAULT 1,
    frente_dorso          ENUM('si','no') DEFAULT 'no',
    usa_troquel           TINYINT(1) DEFAULT 0,
    troquel_id            INT DEFAULT NULL,
    ruta_maquinas         VARCHAR(500),
    ruta_maquinas_nombres TEXT,
    poses_por_pliego      INT,
    pliegos_necesarios    INT,
    horas_estimadas       DECIMAL(10,2),
    costo_papel           DECIMAL(12,2),
    costo_impresion       DECIMAL(12,2),
    costo_total           DECIMAL(12,2),
    porcentaje_ganancia   FLOAT DEFAULT 0,
    ganancia_valor        DECIMAL(12,2),
    porcentaje_comision   FLOAT DEFAULT 0,
    comision_valor        DECIMAL(12,2),
    porcentaje_iva        FLOAT DEFAULT 19,
    iva_valor             DECIMAL(12,2),
    precio_final          DECIMAL(12,2),
    estado                ENUM('borrador','enviado','aprobado','rechazado') DEFAULT 'borrador',
    observaciones         TEXT,
    creado_en             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
    FOREIGN KEY (papel_id)   REFERENCES insumos(id) ON DELETE SET NULL,
    INDEX idx_cliente (cliente_id),
    INDEX idx_estado  (estado),
    INDEX idx_fecha   (creado_en)
);

-- ─── Datos de prueba ──────────────────────────────────────────────────────────
INSERT INTO maquinas (nombre, formato_max_ancho, formato_max_largo, formato_min_ancho, formato_min_largo, medida_pinza, costo_hora, costo_puesta, velocidad_por_hora) VALUES
('Heidelberg GTO 52', 37.0, 52.0, 10.5, 14.5, 1.0, 15000.00, 5000.00, 5000),
('Komori Lithrone 28', 72.0, 52.0, 20.0, 28.0, 1.2, 25000.00, 8000.00, 8000),
('Guillotina Manual', 72.0, 102.0, 5.0, 5.0, 0, 3000.00, 0, 2000),
('Minerva Troqueladora', 52.0, 37.0, 5.0, 5.0, 0, 8000.00, 2000.00, 1500);

INSERT INTO insumos (tipo, nombre, gramaje, formato_ancho, formato_largo, costo_unidad, unidades_por_paquete, vias) VALUES
('papel', 'Couche Brillante 150g', 150, 72.0, 102.0, 50000.00, 500, 1),
('papel', 'Opalina 250g', 250, 72.0, 102.0, 80000.00, 500, 1),
('papel', 'Bond 90g', 90, 72.0, 102.0, 18000.00, 500, 1),
('papel', 'Autocopiante Duplicado 56g', 56, 72.0, 102.0, 60000.00, 500, 2),
('papel', 'Autocopiante Triplicado 56g', 56, 72.0, 102.0, 90000.00, 500, 3),
('tinta', 'Tinta Cyan Proceso', NULL, NULL, NULL, 15000.00, 1, 1),
('chapa', 'Chapa GTO 52', NULL, NULL, NULL, 2500.00, 1, 1);

INSERT INTO formatos_impresion (nombre, ancho, largo) VALUES
('Carta',    21.6, 27.9),
('A4',       21.0, 29.7),
('1/2 Oficio', 16.5, 21.6),
('A3',       29.7, 42.0),
('Doble Carta', 43.2, 27.9);
