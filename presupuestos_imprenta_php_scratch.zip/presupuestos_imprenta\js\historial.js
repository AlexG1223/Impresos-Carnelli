// js/historial.js — PresuPrint Pro

let paginaActual = 0;
let totalPaginas = 1;
let presupuestoActualId = null;

const fmt = v => parseFloat(v || 0).toLocaleString('es-CL', { maximumFractionDigits: 0 });
const fmtFecha = s => new Date(s).toLocaleDateString('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric' });

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    cargarHistorial();

    document.getElementById('btn-filtrar').addEventListener('click', () => {
        paginaActual = 0;
        cargarHistorial();
    });

    document.getElementById('btn-anterior').addEventListener('click', () => {
        if (paginaActual > 0) { paginaActual--; cargarHistorial(); }
    });

    document.getElementById('btn-siguiente').addEventListener('click', () => {
        if (paginaActual < totalPaginas - 1) { paginaActual++; cargarHistorial(); }
    });

    // Filtrar con Enter
    document.getElementById('filtro-busqueda').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') { paginaActual = 0; cargarHistorial(); }
    });

    // Cerrar modal con Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') cerrarModal();
    });
});

// ── Cargar Historial ──────────────────────────────────────────────────────────
async function cargarHistorial() {
    const tbody   = document.getElementById('tbody-historial');
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:var(--text-muted); padding:2rem;">Cargando...</td></tr>';

    const q      = document.getElementById('filtro-busqueda').value.trim();
    const estado = document.getElementById('filtro-estado').value;

    const params = new URLSearchParams({ page: paginaActual });
    if (q)      params.append('q', q);
    if (estado) params.append('estado', estado);

    try {
        const res    = await fetch('api/presupuestos.php?' + params.toString());
        const result = await res.json();

        if (!result.success) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:var(--danger-color); padding:2rem;">Error al cargar datos.</td></tr>';
            return;
        }

        const { items, total, pages } = result.data;
        totalPaginas = pages || 1;

        // Actualizar paginación
        document.getElementById('page-info').innerText = `Página ${paginaActual + 1} de ${totalPaginas} (${total} presupuestos)`;
        document.getElementById('btn-anterior').disabled = paginaActual === 0;
        document.getElementById('btn-siguiente').disabled = paginaActual >= totalPaginas - 1;

        if (!items || items.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:var(--text-muted); padding:3rem;">No se encontraron presupuestos.</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        items.forEach(p => {
            const tr = document.createElement('tr');
            const clienteNombre = p.cliente_nombre || '<span style="color:var(--text-muted); font-style:italic;">Sin cliente</span>';
            const empresa       = p.cliente_empresa ? `<br><small style="color:var(--text-muted);">${p.cliente_empresa}</small>` : '';

            tr.innerHTML = `
                <td style="font-weight:700; color:var(--primary-color);">#${p.id}</td>
                <td style="white-space:nowrap;">${fmtFecha(p.creado_en)}</td>
                <td>${clienteNombre}${empresa}</td>
                <td style="max-width:200px;">
                    <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${p.descripcion}">${p.descripcion}</div>
                </td>
                <td style="font-size:0.8rem; color:var(--text-muted); max-width:150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${p.ruta_maquinas_nombres || ''}">
                    ${p.ruta_maquinas_nombres || '—'}
                </td>
                <td style="text-align:right; font-weight:700; color:var(--success-color);">$${fmt(p.precio_final)}</td>
                <td style="text-align:center;"><span class="badge badge-${p.estado}">${p.estado}</span></td>
                <td style="text-align:center;">
                    <button onclick="verDetalle(${p.id})" class="btn btn-primary btn-sm">Ver</button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        if (typeof feather !== 'undefined') feather.replace();

    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:var(--danger-color); padding:2rem;">Error de red: ${err.message}</td></tr>`;
    }
}

// ── Modal de Detalle ──────────────────────────────────────────────────────────
async function verDetalle(id) {
    presupuestoActualId = id;

    // Cargar presupuesto desde API
    const res    = await fetch(`api/presupuestos.php?page=0&q=${id}`);
    // Mejor: cargar todos y buscar, o hacer un endpoint GET individual.
    // Para simplificar: filtramos por ID ya en la API con q que busca en descripcion/cliente.
    // Hacemos un segundo approach: buscamos en items la que coincida con el ID.
    // Si no está en la página actual, hacemos una búsqueda limpia.
    const params = new URLSearchParams({ page: 0 });
    const r2     = await fetch(`api/presupuestos.php?` + params.toString());
    const all    = await r2.json();

    let p = null;
    if (all.success) {
        // Buscar por ID en todas las páginas — simplificamos buscando en la misma respuesta
        const paramsId = new URLSearchParams({ page: 0, limit: 200 });
        const rAll = await fetch('api/presupuestos.php?' + paramsId.toString());
        const dAll = await rAll.json();
        if (dAll.success) {
            p = dAll.data.items.find(x => parseInt(x.id) === parseInt(id));
        }
    }

    if (!p) {
        alert('No se pudo cargar el presupuesto.');
        return;
    }

    // Poblar modal
    document.getElementById('modal-titulo').innerText  = `Presupuesto #${p.id}`;
    document.getElementById('modal-fecha').innerText   = 'Generado: ' + fmtFecha(p.creado_en);

    // Cliente
    document.getElementById('md-cliente-nombre').innerText   = p.cliente_nombre || '—';
    document.getElementById('md-cliente-empresa').innerText  = p.cliente_empresa || '—';
    document.getElementById('md-cliente-telefono').innerText = p.cliente_telefono || '—';
    document.getElementById('md-cliente-email').innerText    = p.cliente_email || '—';

    // Trabajo
    document.getElementById('md-descripcion').innerText = p.descripcion;
    document.getElementById('md-tipo').innerText        = p.tipo_trabajo === 'troquel' ? 'Con Troquel' : 'Corte Recto';
    document.getElementById('md-dimensiones').innerText = (p.ancho_final && p.largo_final) ? `${p.ancho_final} x ${p.largo_final} cm` : '—';
    document.getElementById('md-cantidad').innerText    = p.cantidad_pedida ? p.cantidad_pedida + ' unidades' : '—';
    document.getElementById('md-ruta').innerText        = p.ruta_maquinas_nombres || '—';
    document.getElementById('md-poses').innerText       = p.poses_por_pliego || '—';
    document.getElementById('md-pliegos').innerText     = p.pliegos_necesarios || '—';
    document.getElementById('md-tiempo').innerText      = p.horas_estimadas ? p.horas_estimadas + ' hr' : '—';

    // Financiero
    document.getElementById('md-costo-papel').innerText = '$' + fmt(p.costo_papel);
    document.getElementById('md-costo-imp').innerText   = '$' + fmt(p.costo_impresion);
    document.getElementById('md-costo-total').innerText = '$' + fmt(p.costo_total);
    document.getElementById('md-ganancia').innerText    = `${p.porcentaje_ganancia}% = $${fmt(p.ganancia_valor)}`;
    document.getElementById('md-comision').innerText    = `${p.porcentaje_comision}% = $${fmt(p.comision_valor)}`;
    document.getElementById('md-iva').innerText         = `${p.porcentaje_iva}% = $${fmt(p.iva_valor)}`;
    document.getElementById('md-precio-final').innerText = '$' + fmt(p.precio_final);

    // Estado
    document.getElementById('md-estado-select').value = p.estado;

    // Observaciones (solo print)
    const obs = p.observaciones || '';
    document.getElementById('md-observaciones-print').innerText = obs || 'Sin observaciones.';

    // Mostrar modal
    document.getElementById('modal-detalle').classList.remove('hidden');
    document.body.style.overflow = 'hidden';

    if (typeof feather !== 'undefined') feather.replace();
}

function cerrarModal() {
    document.getElementById('modal-detalle').classList.add('hidden');
    document.body.style.overflow = '';
    presupuestoActualId = null;
}

// ── Guardar estado ────────────────────────────────────────────────────────────
async function guardarEstado() {
    if (!presupuestoActualId) return;
    const estado = document.getElementById('md-estado-select').value;

    const res    = await fetch('api/presupuestos.php', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: presupuestoActualId, estado })
    });
    const result = await res.json();

    if (result.success) {
        cerrarModal();
        cargarHistorial();
    } else {
        alert('Error al guardar estado: ' + result.message);
    }
}

// ── Eliminar ──────────────────────────────────────────────────────────────────
async function eliminarPresupuesto() {
    if (!presupuestoActualId) return;
    if (!confirm('¿Seguro que deseas eliminar este presupuesto? Esta acción no se puede deshacer.')) return;

    const res    = await fetch('api/presupuestos.php?id=' + presupuestoActualId, { method: 'DELETE' });
    const result = await res.json();

    if (result.success) {
        cerrarModal();
        cargarHistorial();
    } else {
        alert('Error al eliminar: ' + result.message);
    }
}

// ── Imprimir ──────────────────────────────────────────────────────────────────
function imprimirPresupuesto() {
    document.body.classList.add('print-mode');
    window.print();
    setTimeout(() => document.body.classList.remove('print-mode'), 500);
}
