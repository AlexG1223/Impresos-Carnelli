<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

// ─── STATS ────────────────────────────────────────────────────────────────────
if ($method === 'GET' && isset($_GET['stats'])) {
    $mes_actual = date('Y-m');
    $stmt = $pdo->prepare("
        SELECT
            COUNT(*) AS total_mes,
            COALESCE(SUM(CASE WHEN estado = 'aprobado' AND DATE_FORMAT(creado_en,'%Y-%m') = ? THEN precio_final ELSE 0 END), 0) AS ventas_aprobadas_mes,
            COALESCE(AVG(precio_final), 0) AS promedio_precio,
            (SELECT COUNT(DISTINCT cliente_id) FROM presupuestos_guardados WHERE cliente_id IS NOT NULL) AS clientes_unicos
        FROM presupuestos_guardados
        WHERE DATE_FORMAT(creado_en,'%Y-%m') = ?
    ");
    $stmt->execute([$mes_actual, $mes_actual]);
    sendJsonResponse(true, $stmt->fetch());
}

// ─── LISTAR ────────────────────────────────────────────────────────────────────
if ($method === 'GET') {
    $where = [];
    $params = [];

    if (!empty($_GET['estado'])) {
        $where[] = "p.estado = ?";
        $params[] = $_GET['estado'];
    }
    if (!empty($_GET['cliente_id'])) {
        $where[] = "p.cliente_id = ?";
        $params[] = (int)$_GET['cliente_id'];
    }
    if (!empty($_GET['q'])) {
        $where[] = "(p.descripcion LIKE ? OR c.nombre LIKE ? OR c.empresa LIKE ?)";
        $q = '%' . $_GET['q'] . '%';
        $params[] = $q; $params[] = $q; $params[] = $q;
    }

    $page  = max(0, (int)($_GET['page'] ?? 0));
    $limit = 25;
    $offset = $page * $limit;

    $whereSQL = count($where) ? 'WHERE ' . implode(' AND ', $where) : '';

    $sql = "
        SELECT
            p.*,
            c.nombre AS cliente_nombre,
            c.empresa AS cliente_empresa,
            c.telefono AS cliente_telefono,
            c.email AS cliente_email,
            i.nombre AS papel_nombre
        FROM presupuestos_guardados p
        LEFT JOIN clientes c ON p.cliente_id = c.id
        LEFT JOIN insumos i ON p.papel_id = i.id
        $whereSQL
        ORDER BY p.creado_en DESC
        LIMIT $limit OFFSET $offset
    ";

    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM presupuestos_guardados p LEFT JOIN clientes c ON p.cliente_id = c.id $whereSQL");
    $stmtCount->execute($params);
    $total = (int)$stmtCount->fetchColumn();

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    sendJsonResponse(true, [
        'items' => $rows,
        'total' => $total,
        'page'  => $page,
        'pages' => (int)ceil($total / $limit)
    ]);
}

// ─── CREAR ─────────────────────────────────────────────────────────────────────
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) sendJsonResponse(false, null, "Datos inválidos.");

    $cliente_id = $data['cliente_id'] ?? null;

    // Si viene un nuevo cliente, crearlo primero
    if (!$cliente_id && !empty($data['cliente_nuevo']['nombre'])) {
        $cn = $data['cliente_nuevo'];
        $stmt = $pdo->prepare("INSERT INTO clientes (nombre, empresa, telefono, email) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            trim($cn['nombre']),
            trim($cn['empresa'] ?? ''),
            trim($cn['telefono'] ?? ''),
            trim($cn['email'] ?? '')
        ]);
        $cliente_id = $pdo->lastInsertId();
    }

    if (empty($data['descripcion']))
        sendJsonResponse(false, null, "La descripción del trabajo es requerida.");

    $sql = "INSERT INTO presupuestos_guardados (
        cliente_id, descripcion, tipo_trabajo,
        ancho_final, largo_final, cantidad_pedida, demasia_porcentaje,
        papel_id, colores, frente_dorso, usa_troquel, troquel_id,
        ruta_maquinas, ruta_maquinas_nombres,
        poses_por_pliego, pliegos_necesarios, horas_estimadas,
        costo_papel, costo_impresion, costo_total,
        porcentaje_ganancia, ganancia_valor,
        porcentaje_comision, comision_valor,
        porcentaje_iva, iva_valor, precio_final,
        estado, observaciones
    ) VALUES (
        ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
    )";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $cliente_id,
        trim($data['descripcion']),
        $data['tipo_trabajo'] ?? 'corte_recto',
        $data['ancho_final'] ?? null,
        $data['largo_final'] ?? null,
        (int)($data['cantidad_pedida'] ?? 0),
        (float)($data['demasia_porcentaje'] ?? 0),
        $data['papel_id'] ?? null,
        (int)($data['colores'] ?? 1),
        $data['frente_dorso'] ?? 'no',
        $data['usa_troquel'] ? 1 : 0,
        $data['troquel_id'] ?? null,
        $data['ruta_maquinas'] ?? null,
        $data['ruta_maquinas_nombres'] ?? null,
        $data['poses_por_pliego'] ?? null,
        $data['pliegos_necesarios'] ?? null,
        $data['horas_estimadas'] ?? null,
        $data['costo_papel'] ?? null,
        $data['costo_impresion'] ?? null,
        $data['costo_total'] ?? null,
        (float)($data['porcentaje_ganancia'] ?? 0),
        $data['ganancia_valor'] ?? null,
        (float)($data['porcentaje_comision'] ?? 0),
        $data['comision_valor'] ?? null,
        (float)($data['porcentaje_iva'] ?? 19),
        $data['iva_valor'] ?? null,
        $data['precio_final'] ?? null,
        $data['estado'] ?? 'borrador',
        trim($data['observaciones'] ?? '')
    ]);

    sendJsonResponse(true, ['id' => $pdo->lastInsertId()], "Presupuesto guardado correctamente.");
}

// ─── ACTUALIZAR ESTADO / OBSERVACIONES ────────────────────────────────────────
if ($method === 'PATCH') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data || empty($data['id'])) sendJsonResponse(false, null, "ID requerido.");

    $sets = [];
    $params = [];

    if (isset($data['estado'])) {
        $sets[] = "estado = ?";
        $params[] = $data['estado'];
    }
    if (isset($data['observaciones'])) {
        $sets[] = "observaciones = ?";
        $params[] = $data['observaciones'];
    }

    if (empty($sets)) sendJsonResponse(false, null, "Nada que actualizar.");

    $params[] = $data['id'];
    $stmt = $pdo->prepare("UPDATE presupuestos_guardados SET " . implode(', ', $sets) . " WHERE id = ?");
    $stmt->execute($params);
    sendJsonResponse(true, null, "Actualizado correctamente.");
}

// ─── ELIMINAR ─────────────────────────────────────────────────────────────────
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) sendJsonResponse(false, null, "ID no proporcionado.");
    $stmt = $pdo->prepare("DELETE FROM presupuestos_guardados WHERE id = ?");
    $stmt->execute([$id]);
    sendJsonResponse(true, null, "Presupuesto eliminado.");
}

sendJsonResponse(false, null, "Método no soportado.");
?>
