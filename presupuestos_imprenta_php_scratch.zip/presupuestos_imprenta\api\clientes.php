<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT * FROM clientes ORDER BY nombre ASC");
        sendJsonResponse(true, $stmt->fetchAll());
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || empty($data['nombre']))
            sendJsonResponse(false, null, "El nombre del cliente es requerido.");

        if (isset($data['id']) && $data['id']) {
            $stmt = $pdo->prepare("UPDATE clientes SET nombre=?, empresa=?, telefono=?, email=? WHERE id=?");
            $stmt->execute([
                trim($data['nombre']),
                trim($data['empresa'] ?? ''),
                trim($data['telefono'] ?? ''),
                trim($data['email'] ?? ''),
                $data['id']
            ]);
            sendJsonResponse(true, ['id' => $data['id']], "Cliente actualizado.");
        } else {
            $stmt = $pdo->prepare("INSERT INTO clientes (nombre, empresa, telefono, email) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                trim($data['nombre']),
                trim($data['empresa'] ?? ''),
                trim($data['telefono'] ?? ''),
                trim($data['email'] ?? '')
            ]);
            sendJsonResponse(true, ['id' => $pdo->lastInsertId()], "Cliente creado correctamente.");
        }
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? null;
        if (!$id) sendJsonResponse(false, null, "ID no proporcionado.");
        $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
        $stmt->execute([$id]);
        sendJsonResponse(true, null, "Cliente eliminado.");
        break;

    default:
        sendJsonResponse(false, null, "Método no soportado.");
}
?>
